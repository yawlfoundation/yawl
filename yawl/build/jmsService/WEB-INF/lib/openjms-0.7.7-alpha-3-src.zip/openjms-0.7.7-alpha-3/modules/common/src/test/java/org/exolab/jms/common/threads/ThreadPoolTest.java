/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2002-2004 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: ThreadPoolTest.java,v 1.1 2004/11/26 01:50:36 tanderson Exp $
 */
package org.exolab.jms.common.threads;

import java.util.HashSet;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.exolab.jms.common.threads.CompletionListener;
import org.exolab.jms.common.threads.ThreadPool;


/**
 * This class tests the behaviour of the ThreadPool
 *
 * @author      <a href="mailto:mourikis@intalio.com>Jim Mourikis</a>  
 * @author      <a href="mailto:tima@intalio.com">Tim Anderson</a>
 * @version     $Revision: 1.1 $
 * @see         ThreadPool
 * @see         CompletionListener
 */
public class ThreadPoolTest extends TestCase {

    /**
     * The logger
     */
    private static final Log _log = LogFactory.getLog(ThreadPoolTest.class);


    /**
     * Construct an instance of this class for a specific test case.
     *
     * @param name the name of test case
     */
    public ThreadPoolTest(String name) {
        super(name);
    }

    /**
     * Sets up the test suite
     *
     * @return a test suite
     */
    public static Test suite() {
        return new TestSuite(ThreadPoolTest.class);
    }

    /**
     * Test ThreadPool#execute, by creating some Runnable objects and getting 
     * a thread from the pool to execute them.
     *
     * @throws Exception for any error
     */
    public void testExecute() throws Exception {

        ThreadPool pool = new ThreadPool(3);

        Runnable ra = RunnableHelper.makeRunnable("Worker A", 3000);
        pool.execute(ra);
        
        Runnable rb = RunnableHelper.makeRunnable("Worker B", 1000);
        pool.execute(rb);

        Runnable rc = RunnableHelper.makeRunnable("Worker C", 2000);
        pool.execute(rc);

        Runnable rd = RunnableHelper.makeRunnable("Worker D", 6000);
        pool.execute(rd);

        Runnable re = RunnableHelper.makeRunnable("Worker E", 1000);
        pool.execute(re);

        Thread.currentThread().sleep(15000);
        pool.stopRequestAllWorkers();
    }    

    /**
     * Test ThreadPool#queue, by creating some Runnable some objects,
     * queueing them, and verifying that they execute
     *
     * @throws Exception for any error
     */
    public void testQueue() throws Exception {
        ThreadPool pool = new ThreadPool(3);

        TestListener listener = new TestListener();
        Runnable ra = RunnableHelper.makeRunnable("Worker A", 3000);
        listener.addTarget(ra);
        pool.queue(ra, listener);
        
        Runnable rb = RunnableHelper.makeRunnable("Worker B", 1000);
        listener.addTarget(rb);
        pool.queue(rb, listener);
        
        Runnable rc = RunnableHelper.makeRunnable("Worker C", 2000);
        listener.addTarget(rc);
        pool.queue(rc, listener);
        
        Runnable rd = RunnableHelper.makeRunnable("Worker D", 6000);
        listener.addTarget(rd);
        pool.queue(rd, listener);
        
        Runnable re = RunnableHelper.makeRunnable("Worker E", 1000);
        listener.addTarget(re);
        pool.queue(re, listener);

        Thread.currentThread().sleep(15000);
        pool.stopRequestAllWorkers();

        if (listener.getCompleted() != 5) {
            fail("Only " + listener.getCompleted()
                 + " workers completed in the allocated time");
        }

        if (listener.getErrors() != 0) {
            fail("CompletionListener detected " + listener.getErrors() + 
                 " errors");
        }
    }

    private class TestListener implements CompletionListener {

        private HashSet _targets = new HashSet();
        private HashSet _completed = new HashSet();
        int _errors = 0;

        public void addTarget(Runnable target) {
            _targets.add(target);
        }

        public synchronized void completed(Runnable target) {
            if (_targets.contains(target)) {
                if (!_completed.contains(target)) {
                    _completed.add(target);
                    _log.debug(target + " has completed");
                } else {
                    _log.error(target + " has already completed");
                    ++_errors;
                }
            } else {
                _log.error("Target=" + target + " not registered "
                           + "with the completion listener");
                ++_errors;
            }
        }
        
        public synchronized int getCompleted() {
            return _completed.size();
        }

        public synchronized int getErrors() {
            return _errors;
        }

    } //-- TestListener

    public static class RunnableHelper {

        /**
         * A simple method to return a runnable object that can be used
         * to run on a thread from the pool
         *
         * @param name the name of the object for tracking purposes.
         * @param firstDelay when started, sleep for this long
         * @return a runnable object
         */
        public static Runnable makeRunnable(final String name, 
                                            final long firstDelay) {
            return new Runnable() {
                public void run() {
                    try {
                        _log.debug(name + ": starting up");
                        Thread.sleep(firstDelay);
                        _log.debug(name + ": doing some stuff");
                        Thread.sleep(2000);
                        _log.debug(name + ": leaving");
                    } catch (InterruptedException exception) {
                        _log.debug(name + ": got interrupted!");
                    } catch (Exception exception) {
                        _log.error(exception.getMessage(), exception);
                    }
                }

                public String toString() {
                    return name;
                }
            };
        }
    } //-- RunnableHelper
    
} //-- ThreadPoolTest
