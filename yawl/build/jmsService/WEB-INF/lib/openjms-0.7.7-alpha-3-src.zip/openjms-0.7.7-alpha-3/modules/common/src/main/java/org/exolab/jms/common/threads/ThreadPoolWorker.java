/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 2000-2004 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: ThreadPoolWorker.java,v 1.1 2004/11/26 01:50:35 tanderson Exp $
 */
package org.exolab.jms.common.threads;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.exolab.jms.common.util.FifoQueue;


/**
 * This class creates an internal thread, adds it to the idleThread queue
 * and starts it running. The thread will then block on an internal queue
 * waitUntilWork for a runnable object to be passed to it. Once invoked
 * the thread will then call the objects run method.
 *
 * @version     $Revision: 1.1 $ $Date: 2004/11/26 01:50:35 $
 * @author      <a href="mailto:mourikis@exolab.org">Jim Mourikis</a>
 * @see         ThreadPool
 * @see         FifoQueue
 */
class ThreadPoolWorker {

    /**
     * The thread group that this worker is a member of
     */
    private ThreadGroup _group;

    /**
     * A reference to the idle work queue for this ThreadPool.
     */
    private FifoQueue _idleWorkers;

    /**
     * Used to make the thread block until there is something to do. Runnable
     * objects are passed to the thread in a thread safe manner through
     * this queue.
     */
    private FifoQueue _waitUntilWork;

    /**
     * The worker thread
     */
    private Thread _worker;

    /**
     * An internal flag used to notify the thread to stop nicely
     */
    private volatile boolean _noStopRequested;

    /**
     * The logger
     */
    private static final Log _log = LogFactory.getLog(ThreadPoolWorker.class);

    /**
     * The constructor creates the worker thread and runs it.
     * The new thread is given a unique id and added to the idle work queue.
     * The thread will then sleep until it is allocated work.
     *
     * @param group the thread group that the worker is a member of
     * @param name the name of the thread. This must be unique.
     * @param idleWorkers a reference to the idle worker queue
     */
    public ThreadPoolWorker(ThreadGroup group, String name,
                            FifoQueue idleWorkers) {
        _group = group;
        _idleWorkers = idleWorkers;

        // Note: Only 1 item is allowed in this queue.
        _waitUntilWork = new FifoQueue(1);
        _noStopRequested = true;

        Runnable r = new Runnable() {
            public void run() {
                try {
                    runWork();
                } catch (Exception exception) {
                    _log.error("Thread " + _worker.getName()
                               + ": terminating on exception", exception);
                }
            }
        };

        // Create the new internal thread and start it all off.
        _worker = new Thread(_group, r, name);
        _worker.setDaemon(_group.isDaemon());
        _worker.start();
    }

    /**
     * This method passes an external runnable object to a waiting thread.
     * The thread is woken up and begins to run.
     *
     * @param target the target to run
     * @throws InterruptedException If this thread is interrupted externally
     */
    public void process(Runnable target) throws InterruptedException {
        _waitUntilWork.add(target);
    }

    /**
     * The thread is requested to stop.
     * Set the flag and issue an interrupt request.
     */
    public void stopRequest() {
        _noStopRequested = false;
        _worker.interrupt();
    }

    /**
     * Determines if the thread is still alive.
     *
     * @return <code>true</code> if the thread is still alive
     */
    public boolean isAlive() {
        return _worker.isAlive();
    }

    /**
     * The thread's main loop. A thread begins to run here and blocks until
     * a runnable object is passed to it via the waitUntilWork queue.
     */
    private void runWork() {
        while (_noStopRequested) {
            try {
                // Worker is ready work. This will never block since the
                // idleWorker queue has enough capacity for all of
                // the workers.
                _idleWorkers.add(this);

                // wait here until the server allocates work
                Runnable r = (Runnable) _waitUntilWork.get();

                runIt(r);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt(); // re-assert
            }
        }
    }

    /**
     * The thread runs here, passing control to the external Runnable
     * object.
     *
     * @param r the target to run
     */
    private void runIt(Runnable r) {
        try {
            r.run();
        } catch (Exception exception) {
            // catch any and all exceptions
            _log.error("Thread " + _worker.getName()
                       + ": uncaught exception fell through from run()",
                       exception);
        } finally {
            // Clear the interrupted flag (in case it comes back set)
            // so that if the loop goes again, the
            // _waitUntilWork.get() does not mistakenly throw
            // an InterruptedException.
            Thread.interrupted();
        }
    }

}
