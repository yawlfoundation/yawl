' This file is made available under the terms of the LGPL licence.
' This licence can be retreived from http://www.gnu.org/copyleft/lesser.html.
' The source remains the property of the YAWL Group.  The YAWL Group is a 
' collaboration of individuals and organisations who are commited to improving 
' workflow technology.

Imports System.IO

Public Class frmConfig
    Inherits System.Windows.Forms.Form

    Private myPath As String = Application.StartupPath
    Private OKToClose = True

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtRepository As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtYAWLEditor As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnRepository As System.Windows.Forms.Button
    Friend WithEvents btnYAWLEditor As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents BrowserDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents txtServiceURI As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtRepository = New System.Windows.Forms.TextBox
        Me.btnOK = New System.Windows.Forms.Button
        Me.txtYAWLEditor = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtServiceURI = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnRepository = New System.Windows.Forms.Button
        Me.btnYAWLEditor = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.BrowserDialog = New System.Windows.Forms.FolderBrowserDialog
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Worklet Repository:"
        '
        'txtRepository
        '
        Me.txtRepository.Location = New System.Drawing.Point(136, 16)
        Me.txtRepository.Name = "txtRepository"
        Me.txtRepository.Size = New System.Drawing.Size(304, 20)
        Me.txtRepository.TabIndex = 1
        Me.txtRepository.Text = "TextBox1"
        '
        'btnOK
        '
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnOK.Location = New System.Drawing.Point(152, 136)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.TabIndex = 8
        Me.btnOK.Text = "OK"
        '
        'txtYAWLEditor
        '
        Me.txtYAWLEditor.Location = New System.Drawing.Point(136, 56)
        Me.txtYAWLEditor.Name = "txtYAWLEditor"
        Me.txtYAWLEditor.Size = New System.Drawing.Size(304, 20)
        Me.txtYAWLEditor.TabIndex = 4
        Me.txtYAWLEditor.Text = "TextBox2"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "YAWL Editor:"
        '
        'txtServiceURI
        '
        Me.txtServiceURI.Location = New System.Drawing.Point(136, 96)
        Me.txtServiceURI.Name = "txtServiceURI"
        Me.txtServiceURI.Size = New System.Drawing.Size(304, 20)
        Me.txtServiceURI.TabIndex = 7
        Me.txtServiceURI.Text = "TextBox3"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 98)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 23)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Worklet Service URI:"
        '
        'btnRepository
        '
        Me.btnRepository.Location = New System.Drawing.Point(456, 16)
        Me.btnRepository.Name = "btnRepository"
        Me.btnRepository.Size = New System.Drawing.Size(24, 23)
        Me.btnRepository.TabIndex = 2
        Me.btnRepository.Text = "..."
        '
        'btnYAWLEditor
        '
        Me.btnYAWLEditor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnYAWLEditor.Location = New System.Drawing.Point(456, 56)
        Me.btnYAWLEditor.Name = "btnYAWLEditor"
        Me.btnYAWLEditor.Size = New System.Drawing.Size(24, 23)
        Me.btnYAWLEditor.TabIndex = 5
        Me.btnYAWLEditor.Text = "..."
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(248, 136)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 9
        Me.btnCancel.Text = "Cancel"
        '
        'BrowserDialog
        '
        Me.BrowserDialog.RootFolder = System.Environment.SpecialFolder.MyComputer
        Me.BrowserDialog.ShowNewFolderButton = False
        '
        'frmConfig
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(498, 168)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnYAWLEditor)
        Me.Controls.Add(Me.btnRepository)
        Me.Controls.Add(Me.txtServiceURI)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtYAWLEditor)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtRepository)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmConfig"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configure Paths"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' load paths to resources from file, or set to defaults
    Private Sub frmConfig_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If File.Exists(myPath & "\RulesEditor.cfg") Then
            LoadPathsFromFile()
        Else
            LoadDefaultPaths()
        End If
    End Sub

    Friend Sub LoadPathsFromFile()
        Dim cfgStream As StreamReader
        Dim cfgLine As String

        Try
            cfgStream = New StreamReader(myPath & "\RulesEditor.cfg")
            cfgLine = cfgStream.ReadLine
            txtRepository.Text = cfgLine.Substring(cfgLine.LastIndexOf("="c) + 1)
            cfgLine = cfgStream.ReadLine
            txtYAWLEditor.Text = cfgLine.Substring(cfgLine.LastIndexOf("="c) + 1)
            cfgLine = cfgStream.ReadLine
            txtServiceURI.Text = cfgLine.Substring(cfgLine.LastIndexOf("="c) + 1)
        Catch ex As Exception
            MessageBox.Show("Problem loading config - will use defaults", _
                            "Config File", MessageBoxButtons.OK, MessageBoxIcon.Error)
            LoadDefaultPaths()
        Finally
            If Not cfgStream Is Nothing Then cfgStream.Close()
        End Try

    End Sub

    Friend Sub SavePathsToFile()
        Dim cfgStream As StreamWriter

        If Not GoodPaths() Then
            OKToClose = False
            Exit Sub
        Else
            OKToClose = True
        End If

        Try
            cfgStream = New StreamWriter(myPath & "\RulesEditor.cfg")
            cfgStream.WriteLine("Repository=" & txtRepository.Text)
            cfgStream.WriteLine("YAWLEditor=" & txtYAWLEditor.Text)
            cfgStream.WriteLine("ServiceURL=" & txtServiceURI.Text)
        Catch ex As Exception
            MessageBox.Show("Problem saving config", _
                            "Config File", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If Not cfgStream Is Nothing Then cfgStream.Close()
        End Try

    End Sub

    Friend Sub LoadDefaultPaths()
        'put some default paths in the inputs
        txtRepository.Text = myPath.Substring(0, myPath.LastIndexOf("\"c))
        txtYAWLEditor.Text = myPath
        txtServiceURI.Text = "http://localhost:8080/workletSelector"
    End Sub

    Friend Function GoodPaths() As Boolean
        Return GoodRepositoryPath() AndAlso GoodYAWLEditorPath() AndAlso ValidServiceURI()
    End Function

    Private Function GoodRepositoryPath() As Boolean
        ' checks for a valid repository path
        Dim errStr As String
        If Not (Directory.Exists(txtRepository.Text & "\rules") OrElse _
                Directory.Exists(txtRepository.Text & "\selected") OrElse _
                Directory.Exists(txtRepository.Text & "\worklets")) Then
            MessageBox.Show("It appears the repository path specified is incorrect," & _
                            " or doesn't contain the required folders 'rules'," & _
                            " 'worklets' and/or 'selected'. Please correct the" & _
                            " path to the repository.", "Invalid Repository Path", _
                             MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Else
            Return True
        End If
    End Function

    Private Function GoodYAWLEditorPath() As Boolean
        ' checks for a valid YAWL Editor path
        Dim errStr As String
        If Not File.Exists(txtYAWLEditor.Text & "\YAWLEditor1.3.jar") Then
            MessageBox.Show("It appears the YAWLEditor path specified is incorrect," & _
                            " or doesn't contain the editor jar file." & _
                            " Please correct the path to the YAWL Editor.", _
                            "Invalid YAWLEditor Path", _
                             MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Else
            Return True
        End If
    End Function

    Private Function ValidServiceURI() As Boolean
        ' checks if the supplied uri is well-formed
        Dim uri As Uri
        Try
            uri = New Uri(txtServiceURI.Text)
            Return True
        Catch ex As Exception
            MessageBox.Show("It appears the Worklet Service URI specified is incorrect," & _
                " or is not a valid URI." & _
                " Please correct the URI specified.", _
                "Invalid Worklet Service URI", _
                 MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub btnRepository_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRepository.Click
        doBrowse(txtRepository, 0)
    End Sub

    Private Sub btnYAWLEditor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnYAWLEditor.Click
        doBrowse(txtYAWLEditor, 1)
    End Sub

    Private Sub doBrowse(ByVal txtPath As TextBox, ByVal idx As Integer)
        Dim msg As String() = {"Select the worklet repository folder", _
                               "Select the folder that contains the yawl editor (v1.3)"}
        ' show a folder browser
        With BrowserDialog
            .Description = msg(idx)
            .SelectedPath = txtPath.Text
            If .ShowDialog() = DialogResult.OK Then
                txtPath.Text = .SelectedPath
            End If
        End With
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        SavePathsToFile()
    End Sub

    Private Sub frmConfig_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        e.Cancel = Not OKToClose
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'if Cancel, let it close
        OKToClose = True
    End Sub
End Class
