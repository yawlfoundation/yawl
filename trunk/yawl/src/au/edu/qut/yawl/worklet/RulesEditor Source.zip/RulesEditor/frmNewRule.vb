' This file is made available under the terms of the LGPL licence.
' This licence can be retreived from http://www.gnu.org/copyleft/lesser.html.
' The source remains the property of the YAWL Group.  The YAWL Group is a 
' collaboration of individuals and organisations who are commited to improving 
' workflow technology.

Imports System.Xml
Imports System.IO

Public Class frmNewRule
    Inherits System.Windows.Forms.Form

    ' store info about the new rule set
    Public specName As String
    Public newNode As frmEdit.sNode
    Public task As frmEdit.sTask
    Public newCS As New ArrayList(20)
    Public pathOf As frmEdit.sConfig

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtParent As System.Windows.Forms.TextBox
    Friend WithEvents txtCondition As System.Windows.Forms.TextBox
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents cbxWorklets As System.Windows.Forms.ComboBox
    Friend WithEvents proEditor As System.Diagnostics.Process
    Friend WithEvents btnEditor As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtCSLabel As System.Windows.Forms.TextBox
    Friend WithEvents txtCSValue As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTaskName As System.Windows.Forms.TextBox
    Friend WithEvents txtSpecName As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lbxCornerstone As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmNewRule))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lbxCornerstone = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btnEditor = New System.Windows.Forms.Button
        Me.cbxWorklets = New System.Windows.Forms.ComboBox
        Me.txtDesc = New System.Windows.Forms.TextBox
        Me.txtParent = New System.Windows.Forms.TextBox
        Me.txtCondition = New System.Windows.Forms.TextBox
        Me.txtID = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.proEditor = New System.Diagnostics.Process
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnAdd = New System.Windows.Forms.Button
        Me.txtCSValue = New System.Windows.Forms.TextBox
        Me.txtCSLabel = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtTaskName = New System.Windows.Forms.TextBox
        Me.txtSpecName = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbxCornerstone)
        Me.GroupBox1.Location = New System.Drawing.Point(288, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(152, 216)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cornerstone Case Data"
        '
        'lbxCornerstone
        '
        Me.lbxCornerstone.BackColor = System.Drawing.SystemColors.Window
        Me.lbxCornerstone.Location = New System.Drawing.Point(3, 16)
        Me.lbxCornerstone.Name = "lbxCornerstone"
        Me.lbxCornerstone.Size = New System.Drawing.Size(141, 186)
        Me.lbxCornerstone.TabIndex = 0
        Me.lbxCornerstone.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnEditor)
        Me.GroupBox3.Controls.Add(Me.cbxWorklets)
        Me.GroupBox3.Controls.Add(Me.txtDesc)
        Me.GroupBox3.Controls.Add(Me.txtParent)
        Me.GroupBox3.Controls.Add(Me.txtCondition)
        Me.GroupBox3.Controls.Add(Me.txtID)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 232)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(432, 160)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "New Rule 1 Node"
        '
        'btnEditor
        '
        Me.btnEditor.Location = New System.Drawing.Point(328, 74)
        Me.btnEditor.Name = "btnEditor"
        Me.btnEditor.Size = New System.Drawing.Size(88, 23)
        Me.btnEditor.TabIndex = 4
        Me.btnEditor.Text = "&New..."
        '
        'cbxWorklets
        '
        Me.cbxWorklets.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxWorklets.Location = New System.Drawing.Point(80, 75)
        Me.cbxWorklets.Name = "cbxWorklets"
        Me.cbxWorklets.Size = New System.Drawing.Size(240, 21)
        Me.cbxWorklets.TabIndex = 3
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(80, 104)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(336, 48)
        Me.txtDesc.TabIndex = 6
        Me.txtDesc.Text = ""
        '
        'txtParent
        '
        Me.txtParent.Location = New System.Drawing.Point(216, 18)
        Me.txtParent.Name = "txtParent"
        Me.txtParent.ReadOnly = True
        Me.txtParent.Size = New System.Drawing.Size(32, 20)
        Me.txtParent.TabIndex = 8
        Me.txtParent.TabStop = False
        Me.txtParent.Text = "0"
        '
        'txtCondition
        '
        Me.txtCondition.Location = New System.Drawing.Point(80, 48)
        Me.txtCondition.Name = "txtCondition"
        Me.txtCondition.Size = New System.Drawing.Size(336, 20)
        Me.txtCondition.TabIndex = 1
        Me.txtCondition.Text = ""
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(80, 19)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(32, 20)
        Me.txtID.TabIndex = 6
        Me.txtID.TabStop = False
        Me.txtID.Text = "1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 16)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Description:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 16)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Worklet:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 16)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Condition:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(128, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Parent Node ID:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Node ID:"
        '
        'btnSave
        '
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnSave.Enabled = False
        Me.btnSave.Location = New System.Drawing.Point(104, 400)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(88, 23)
        Me.btnSave.TabIndex = 3
        Me.btnSave.Text = "C&reate"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(240, 400)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 23)
        Me.btnCancel.TabIndex = 4
        Me.btnCancel.Text = "Cancel"
        '
        'proEditor
        '
        Me.proEditor.EnableRaisingEvents = True
        Me.proEditor.StartInfo.Arguments = "-jar YAWLEditor1.3.jar"
        Me.proEditor.StartInfo.CreateNoWindow = True
        Me.proEditor.StartInfo.FileName = "java"
        Me.proEditor.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
        Me.proEditor.SynchronizingObject = Me
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnAdd)
        Me.GroupBox2.Controls.Add(Me.txtCSValue)
        Me.GroupBox2.Controls.Add(Me.txtCSLabel)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 104)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(272, 120)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Add Cornerstone Data"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(176, 88)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.TabIndex = 4
        Me.btnAdd.Text = "&Add -->"
        '
        'txtCSValue
        '
        Me.txtCSValue.Location = New System.Drawing.Point(104, 56)
        Me.txtCSValue.Name = "txtCSValue"
        Me.txtCSValue.Size = New System.Drawing.Size(160, 20)
        Me.txtCSValue.TabIndex = 3
        Me.txtCSValue.Text = ""
        '
        'txtCSLabel
        '
        Me.txtCSLabel.Location = New System.Drawing.Point(104, 24)
        Me.txtCSLabel.Name = "txtCSLabel"
        Me.txtCSLabel.Size = New System.Drawing.Size(160, 20)
        Me.txtCSLabel.TabIndex = 1
        Me.txtCSLabel.Text = ""
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(16, 60)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 23)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Data Value:"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(16, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 23)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Data Label:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtTaskName)
        Me.GroupBox4.Controls.Add(Me.txtSpecName)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(272, 88)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Process Identifiers"
        '
        'txtTaskName
        '
        Me.txtTaskName.Location = New System.Drawing.Point(108, 53)
        Me.txtTaskName.Name = "txtTaskName"
        Me.txtTaskName.Size = New System.Drawing.Size(156, 20)
        Me.txtTaskName.TabIndex = 3
        Me.txtTaskName.Text = ""
        '
        'txtSpecName
        '
        Me.txtSpecName.Location = New System.Drawing.Point(108, 21)
        Me.txtSpecName.Name = "txtSpecName"
        Me.txtSpecName.Size = New System.Drawing.Size(156, 20)
        Me.txtSpecName.TabIndex = 1
        Me.txtSpecName.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(4, 56)
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Task Name:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(4, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Specification Name:"
        '
        'frmNewRule
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 428)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmNewRule"
        Me.Text = "Worklet Rules Editor: Create New Rule Set"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub FillWorkletList()
        ' fill combo with list of worklet spec files
        Dim di As DirectoryInfo = New DirectoryInfo(pathOf.repository & "\worklets")
        Dim fi As FileInfo
        Dim fName As String

        If di Is Nothing Then
            MessageBox.Show("Can't load worklet names because the specified path " & _
                            "is invalid. Please specify a valid path to the " & _
                            "worklet repository folder in Options...Configure.", _
            "Invalid Repository Path", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' add worklet names to file
        For Each fi In di.GetFiles("*.xml")
            fName = fi.Name.Remove(fi.Name.LastIndexOf(".xml"), 4)       ' cut extn
            cbxWorklets.Items.Add(fName)
        Next
        cbxWorklets.Text = cbxWorklets.Items(0)
    End Sub

    Private Sub UpdateWorkletList()
        ' adds names of new worklet(s) to combo
        Dim di As DirectoryInfo = New DirectoryInfo(pathOf.repository & "\worklets")
        Dim fi As FileInfo
        Dim fName As String

        If di Is Nothing Then
            MessageBox.Show("Can't update worklet names because the specified path " & _
                            "is invalid. Please specify a valid path to the " & _
                            "worklet repository folder in Options...Configure.", _
            "Invalid Repository Path", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' add new worklet names to file
        For Each fi In di.GetFiles("*.xml")
            fName = fi.Name.Remove(fi.Name.LastIndexOf(".xml"), 4)

            ' only add new worklets (don't double up in list)
            With cbxWorklets
                If .Items.IndexOf(fName) = -1 Then
                    .Items.Add(fName)
                    .SelectedIndex = .Items.IndexOf(fName)
                End If
            End With
        Next
        cbxWorklets.Text = cbxWorklets.SelectedItem
    End Sub


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ' saves the new rule descriptors to the structure
        Dim errMsg As String = ""
        Dim dataitem As String
        Dim rootCS As New ArrayList(1)

        ' save the spec & task names
        specName = txtSpecName.Text
        task.name = txtTaskName.Text

        ' init task arrays
        task.nodelist = New ArrayList(20)
        task.cslist = New ArrayList(20)

        ' add root node
        With newNode
            .id = "0"
            .parent = "-1"
            .trueChild = "1"
            .falseChild = "-1"
            .condition = "True"
            .conclusion = "null"
            .desc = "default root node"
        End With
        task.nodelist.Add(newNode)
        task.cslist.Add(rootCS)

        'add the new rule 1
        With newNode
            .id = 1
            .parent = 0
            .trueChild = "-1"
            .falseChild = "-1"
            .condition = txtCondition.Text
            .conclusion = cbxWorklets.SelectedItem
            .desc = txtDesc.Text
        End With

        ' and the case data - becomes the cornerstone for this rule
        newCS.Clear()
        For Each dataitem In lbxCornerstone.Items
            newCS.Add(dataitem)
        Next

        task.nodelist.Add(newNode)
        task.cslist.Add(newCS)

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Close()
    End Sub

    Private Sub btnEditor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditor.Click
        ' start the Process to load the YAWL Editor
        proEditor.Start()
    End Sub

    ' event handler that fires when YAWL Editor closes
    Friend Sub ProcessExited(ByVal sender As Object, ByVal e As System.EventArgs)
        UpdateWorkletList()
    End Sub

    Private Sub frmAddRule_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        FillWorkletList()

        proEditor.StartInfo.WorkingDirectory = pathOf.YAWLEditor

        ' add an Exited event handler for the YAWL Editor process
        AddHandler proEditor.Exited, AddressOf Me.ProcessExited
    End Sub


    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        'add a data entry to the cornerstone case data
        Dim newCSEntry As String

        ' make sure there's a label and value provided
        If txtCSLabel.Text.Length = 0 Then
            MessageBox.Show("Please provide a Data Label", "Add Case Data", _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If txtCSValue.Text.Length = 0 Then
            MessageBox.Show("Please provide a Data Value", "Add Case Data", _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        newCSEntry = txtCSLabel.Text & " = " & txtCSValue.Text

        If lbxCornerstone.Items.IndexOf(newCSEntry) = -1 Then
            lbxCornerstone.Items.Add(newCSEntry)
            txtCSLabel.Clear()
            txtCSValue.Clear()
            txtCSLabel.Focus()
        Else
            MessageBox.Show("That data is already in the list", "Add Case Data", _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub RequiredTextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
               Handles txtSpecName.TextChanged, txtTaskName.TextChanged, _
                       txtCondition.TextChanged, cbxWorklets.TextChanged

        'enable the save button when all required entries are provided
        btnSave.Enabled = (txtSpecName.Text.Length > 0) AndAlso _
                          (txtTaskName.Text.Length > 0) AndAlso _
                          (txtCondition.Text.Length > 0) AndAlso _
                          (cbxWorklets.Text.Length > 0)
    End Sub
End Class
