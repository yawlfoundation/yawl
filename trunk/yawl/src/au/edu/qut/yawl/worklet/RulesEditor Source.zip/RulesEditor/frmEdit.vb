' This file is made available under the terms of the LGPL licence.
' This licence can be retreived from http://www.gnu.org/copyleft/lesser.html.
' The source remains the property of the YAWL Group.  The YAWL Group is a 
' collaboration of individuals and organisations who are commited to improving 
' workflow technology.

Imports System.Xml
Imports System.Net
Imports System.IO
Imports System.Text

' the main form for the RulesEditor

Public Class frmEdit
    Inherits System.Windows.Forms.Form

    ' holds one rule node
    Structure sNode
        Public id As String
        Public parent As String
        Public trueChild As String
        Public falseChild As String
        Public condition As String
        Public conclusion As String
        Public desc As String
    End Structure

    ' holds all the rule nodes and cornerstone data for one task
    Structure sTask
        Public name As String
        Public nodelist As ArrayList                     ' list of rule nodes
        Public cslist As ArrayList                       ' list of cornerstone data
    End Structure

    ' contains the paths to various resources used or needed
    Structure sConfig
        Public repository As String
        Public YAWLEditor As String
        Public ServiceURL As String
    End Structure

    Private spec As String                              ' spec name
    Private fName As String                             ' selected file
    Private tasks() As sTask                            ' set of tasks in this spec
    Private loadingRules As Boolean = False             ' flag to prevent double load
    Public pathOf As sConfig                            ' resource paths

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbxTasks As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents txtCondition As System.Windows.Forms.TextBox
    Friend WithEvents txtParent As System.Windows.Forms.TextBox
    Friend WithEvents txtConclusion As System.Windows.Forms.TextBox
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lbxCornerstone As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents tvRules As System.Windows.Forms.TreeView
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents mFile As System.Windows.Forms.MenuItem
    Friend WithEvents mNew As System.Windows.Forms.MenuItem
    Friend WithEvents mOpen As System.Windows.Forms.MenuItem
    Friend WithEvents mClose As System.Windows.Forms.MenuItem
    Friend WithEvents mExit As System.Windows.Forms.MenuItem
    Friend WithEvents mRule As System.Windows.Forms.MenuItem
    Friend WithEvents mAdd As System.Windows.Forms.MenuItem
    Friend WithEvents mOptions As System.Windows.Forms.MenuItem
    Friend WithEvents mConfigure As System.Windows.Forms.MenuItem
    Friend WithEvents mHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mAbout As System.Windows.Forms.MenuItem
    Friend WithEvents imlNodes As System.Windows.Forms.ImageList
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmEdit))
        Me.Label1 = New System.Windows.Forms.Label
        Me.cbxTasks = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtDesc = New System.Windows.Forms.TextBox
        Me.txtConclusion = New System.Windows.Forms.TextBox
        Me.txtParent = New System.Windows.Forms.TextBox
        Me.txtCondition = New System.Windows.Forms.TextBox
        Me.txtID = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbxCornerstone = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.tvRules = New System.Windows.Forms.TreeView
        Me.imlNodes = New System.Windows.Forms.ImageList(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.mFile = New System.Windows.Forms.MenuItem
        Me.mNew = New System.Windows.Forms.MenuItem
        Me.mOpen = New System.Windows.Forms.MenuItem
        Me.mClose = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.mExit = New System.Windows.Forms.MenuItem
        Me.mRule = New System.Windows.Forms.MenuItem
        Me.mAdd = New System.Windows.Forms.MenuItem
        Me.mOptions = New System.Windows.Forms.MenuItem
        Me.mConfigure = New System.Windows.Forms.MenuItem
        Me.mHelp = New System.Windows.Forms.MenuItem
        Me.mAbout = New System.Windows.Forms.MenuItem
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Task: "
        '
        'cbxTasks
        '
        Me.cbxTasks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxTasks.Location = New System.Drawing.Point(57, 8)
        Me.cbxTasks.Name = "cbxTasks"
        Me.cbxTasks.Size = New System.Drawing.Size(121, 21)
        Me.cbxTasks.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtDesc)
        Me.GroupBox1.Controls.Add(Me.txtConclusion)
        Me.GroupBox1.Controls.Add(Me.txtParent)
        Me.GroupBox1.Controls.Add(Me.txtCondition)
        Me.GroupBox1.Controls.Add(Me.txtID)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 248)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(432, 160)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Selected Node"
        '
        'txtDesc
        '
        Me.txtDesc.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtDesc.Location = New System.Drawing.Point(80, 104)
        Me.txtDesc.Multiline = True
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.ReadOnly = True
        Me.txtDesc.Size = New System.Drawing.Size(336, 48)
        Me.txtDesc.TabIndex = 10
        Me.txtDesc.TabStop = False
        Me.txtDesc.Text = ""
        '
        'txtConclusion
        '
        Me.txtConclusion.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtConclusion.Location = New System.Drawing.Point(80, 76)
        Me.txtConclusion.Name = "txtConclusion"
        Me.txtConclusion.ReadOnly = True
        Me.txtConclusion.Size = New System.Drawing.Size(336, 20)
        Me.txtConclusion.TabIndex = 9
        Me.txtConclusion.TabStop = False
        Me.txtConclusion.Text = ""
        '
        'txtParent
        '
        Me.txtParent.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtParent.Location = New System.Drawing.Point(216, 18)
        Me.txtParent.Name = "txtParent"
        Me.txtParent.ReadOnly = True
        Me.txtParent.Size = New System.Drawing.Size(32, 20)
        Me.txtParent.TabIndex = 8
        Me.txtParent.TabStop = False
        Me.txtParent.Text = ""
        '
        'txtCondition
        '
        Me.txtCondition.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtCondition.Location = New System.Drawing.Point(80, 48)
        Me.txtCondition.Name = "txtCondition"
        Me.txtCondition.ReadOnly = True
        Me.txtCondition.Size = New System.Drawing.Size(336, 20)
        Me.txtCondition.TabIndex = 7
        Me.txtCondition.TabStop = False
        Me.txtCondition.Text = ""
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txtID.Location = New System.Drawing.Point(80, 19)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(32, 20)
        Me.txtID.TabIndex = 6
        Me.txtID.TabStop = False
        Me.txtID.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 16)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Description:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 16)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Worklet:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Condition:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(128, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Parent Node ID:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Node ID:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lbxCornerstone)
        Me.GroupBox2.Location = New System.Drawing.Point(288, 40)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(152, 200)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Cornerstone Case"
        '
        'lbxCornerstone
        '
        Me.lbxCornerstone.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lbxCornerstone.Location = New System.Drawing.Point(3, 16)
        Me.lbxCornerstone.Name = "lbxCornerstone"
        Me.lbxCornerstone.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lbxCornerstone.Size = New System.Drawing.Size(141, 173)
        Me.lbxCornerstone.TabIndex = 0
        Me.lbxCornerstone.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.tvRules)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 40)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(272, 200)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "RDR Tree"
        '
        'tvRules
        '
        Me.tvRules.BackColor = System.Drawing.SystemColors.Window
        Me.tvRules.HideSelection = False
        Me.tvRules.ImageList = Me.imlNodes
        Me.tvRules.Location = New System.Drawing.Point(3, 16)
        Me.tvRules.Name = "tvRules"
        Me.tvRules.Size = New System.Drawing.Size(261, 176)
        Me.tvRules.TabIndex = 1
        '
        'imlNodes
        '
        Me.imlNodes.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlNodes.ImageStream = CType(resources.GetObject("imlNodes.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlNodes.TransparentColor = System.Drawing.Color.Transparent
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mFile, Me.mRule, Me.mOptions, Me.mHelp})
        '
        'mFile
        '
        Me.mFile.Index = 0
        Me.mFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mNew, Me.mOpen, Me.mClose, Me.MenuItem6, Me.mExit})
        Me.mFile.Text = "&File"
        '
        'mNew
        '
        Me.mNew.Index = 0
        Me.mNew.Text = "&New..."
        '
        'mOpen
        '
        Me.mOpen.Index = 1
        Me.mOpen.Text = "&Open..."
        '
        'mClose
        '
        Me.mClose.Enabled = False
        Me.mClose.Index = 2
        Me.mClose.Text = "&Close"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 3
        Me.MenuItem6.Text = "-"
        '
        'mExit
        '
        Me.mExit.Index = 4
        Me.mExit.Text = "E&xit"
        '
        'mRule
        '
        Me.mRule.Index = 1
        Me.mRule.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mAdd})
        Me.mRule.Text = "&Rule"
        '
        'mAdd
        '
        Me.mAdd.Enabled = False
        Me.mAdd.Index = 0
        Me.mAdd.Text = "&Add..."
        '
        'mOptions
        '
        Me.mOptions.Index = 2
        Me.mOptions.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mConfigure})
        Me.mOptions.Text = "&Options"
        '
        'mConfigure
        '
        Me.mConfigure.Index = 0
        Me.mConfigure.Text = "Co&nfigure..."
        '
        'mHelp
        '
        Me.mHelp.Index = 3
        Me.mHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mAbout})
        Me.mHelp.Text = "&Help"
        '
        'mAbout
        '
        Me.mAbout.Index = 0
        Me.mAbout.Text = "A&bout..."
        '
        'frmEdit
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 415)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cbxTasks)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Menu = Me.MainMenu1
        Me.Name = "frmEdit"
        Me.Text = "Worklet Rules Editor"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' reads an rdr ruleset file into the editor
    Private Function LoadRules() As Boolean
        Dim x As XmlTextReader
        Dim task As sTask                               ' spec may have several tasks
        Dim ofd As New OpenFileDialog

        Try
            ' show an open dialog tailored for rules file selection
            ofd.Filter = "Worklet Ruleset Files (*.xrs) | *.xrs"
            ofd.InitialDirectory = pathOf.repository & "\rules"
            If ofd.ShowDialog = DialogResult.OK Then

                ' open and read file
                fName = ofd.FileName
                x = New XmlTextReader(fName)
                ExtractSpecName(fName)                        ' show filename in title
                x.WhitespaceHandling = WhitespaceHandling.None

                While x.Read

                    ' a rule file contains only 2 top level elements - task & rulenode
                    If x.NodeType = XmlNodeType.Element Then
                        If x.Name = "task" Then                  ' new task in spec
                            task.name = x.GetAttribute("name")   ' init task structure
                            task.nodelist = New ArrayList(20)
                            task.cslist = New ArrayList(20)
                        ElseIf x.Name = "ruleNode" Then
                            ReadRuleNode(x, task)                ' read a node
                        End If
                    ElseIf x.NodeType = XmlNodeType.EndElement AndAlso _
                           x.Name = "task" Then                  ' end of task block
                        cbxTasks.Items.Add(task.name)            ' list task name
                        If tasks Is Nothing Then
                            ReDim Preserve tasks(0)              ' grow tasks array 
                        Else
                            ReDim Preserve tasks(tasks.Length)
                        End If
                        tasks(tasks.GetUpperBound(0)) = task     ' add this task
                        task = Nothing                           ' re-initialise
                    End If
                End While

                cbxTasks.SelectedIndex = 0                       ' set combo to 1st task
                cbxTasks.Text = cbxTasks.Items(0)
                Return True
            Else ' file open dialog cancelled
                Return False
            End If
        Finally                                                  ' close the file
            If Not x Is Nothing Then x.Close()
        End Try
    End Function

    'remove path and extension from filename to display in titlebar
    Private Sub ExtractSpecName(ByVal s As String)
        s = s.Substring(s.LastIndexOf("\"c) + 1)                 ' remove path
        spec = s.Substring(0, s.IndexOf("."c))                   ' remove extn
        Me.Text = "Worklet Rules Editor: " & spec                ' add to titlebar
    End Sub

    ' read a single rule node from the file
    Private Sub ReadRuleNode(ByVal x As XmlTextReader, ByVal task As sTask)
        Dim item As String                                       ' element name
        Dim node As sNode                                        ' this node
        Dim idx As Integer                                       ' to add rule to list
        Dim datalist As New ArrayList                            ' for cornerstone data

        While x.Read
            If x.NodeType = XmlNodeType.Element Then
                item = x.Name
                If item = "cornerstone" Then                     ' do cs separately
                    datalist = ReadCornerstone(x)
                End If
            ElseIf x.NodeType = XmlNodeType.Text Then
                Select Case item                                 ' update node members
                    Case "id"
                        node.id = x.Value
                    Case "parent"
                        node.parent = x.Value
                    Case "condition"
                        node.condition = x.Value
                    Case "conclusion"
                        node.conclusion = x.Value
                    Case "trueChild"
                        node.trueChild = x.Value
                    Case "falseChild"
                        node.falseChild = x.Value
                    Case "description"
                        node.desc = x.Value
                End Select
            ElseIf x.NodeType = XmlNodeType.EndElement Then
                If x.Name = "ruleNode" Then                      ' end of rulenode def.
                    idx = Convert.ToInt32(node.id)               ' insert in order 
                    task.nodelist.Insert(idx, node)              ' add node to list  
                    task.cslist.Insert(idx, datalist)            ' add cs data to list  
                    Exit While                                   ' ...and we're done 
                End If
            End If
        End While
    End Sub

    ' read cornerstone data items & values
    Private Function ReadCornerstone(ByVal x As XmlTextReader) As ArrayList
        Dim temp As New ArrayList                                ' to store cs data
        Dim item As String                                       ' element name

        While x.Read
            If x.NodeType = XmlNodeType.Element Then             ' get element name  
                item = x.Name
            ElseIf x.NodeType = XmlNodeType.Text Then
                temp.Add(item & " = " & x.Value)                 ' ...then the data
            ElseIf x.NodeType = XmlNodeType.EndElement Then
                If x.Name = "cornerstone" Then                   ' we're done when
                    Return temp                                  ' at end of cs element
                End If
            End If
        End While
    End Function

    'save ruleset back to file (with any additions or changes)
    Private Sub SaveRules()
        Dim idx As Integer                                        ' to loop thru nodes
        Dim node As sNode                                         ' ...one at a time
        Dim xw As XmlTextWriter
        Dim csitem As String                                      ' one data item
        Dim task As sTask                                         ' one task 
        Dim item, value As String

        Try
            ' open the file for writing
            xw = New XmlTextWriter(fName, System.Text.Encoding.UTF8)
            xw.Formatting = Formatting.Indented

            xw.WriteStartDocument()
            xw.WriteStartElement("spec")                          ' top level element

            For Each task In tasks
                xw.WriteStartElement("task")                      ' child task
                xw.WriteAttributeString("name", task.name)

                For idx = 0 To task.nodelist.Count - 1            ' write rules
                    xw.WriteStartElement("ruleNode")
                    node = task.nodelist(idx)

                    WriteElement(xw, "id", node.id)
                    WriteElement(xw, "parent", node.parent)
                    WriteElement(xw, "trueChild", node.trueChild)
                    WriteElement(xw, "falseChild", node.falseChild)
                    WriteElement(xw, "condition", node.condition)
                    WriteElement(xw, "conclusion", node.conclusion)

                    ' cornerstone data is one level lower so is a special case.
                    ' if cornerstone has no data, write fully qualified 
                    ' element(-endelement) otherwise there are problems reading 
                    ' the file in next time
                    xw.WriteStartElement("cornerstone")
                    If task.cslist(idx).count = 0 Then
                        xw.WriteWhitespace(" ")                   ' force full output 
                    Else
                        For Each csitem In task.cslist(idx)
                            item = csitem.Substring(0, csitem.IndexOf("="c) - 1).Trim
                            value = csitem.Substring(csitem.IndexOf("="c) + 1).Trim
                            WriteElement(xw, item, value)
                        Next
                    End If
                    xw.WriteEndElement()      ' cornerstone

                    WriteElement(xw, "description", node.desc)

                    xw.WriteEndElement()      ' rulenode
                Next 'rulenode

                xw.WriteEndElement()          ' task
            Next task

            xw.WriteEndElement()              ' spec
            xw.WriteEndDocument()             ' End Document
            xw.Flush()
        Catch Ex As Exception
        Finally
            If Not xw Is Nothing Then xw.Close()
        End Try
    End Sub

    ' writes <element>data<endelement>
    Private Sub WriteElement(ByVal xw As XmlTextWriter, ByVal name As String, _
                             ByVal value As String)
        xw.WriteStartElement(name)
        If Not value Is Nothing Then
            xw.WriteString(value)
        Else
            xw.WriteWhitespace(" ")      'forces "<name> </name>" instead of "<name/>"
        End If
        xw.WriteEndElement()
    End Sub

    ' loads the rules into the treeview on the gui
    Private Sub LoadTree(ByVal task As sTask)
        tvRules.Nodes.Add("Rule 0")                              ' root node
        AddChildTree(tvRules.Nodes(0), task, 0, True)
        tvRules.ExpandAll()
        tvRules.SelectedNode = tvRules.Nodes(0)                  ' fire selection
    End Sub

    ' recursively add a (child) node to the true (exception) branch
    ' Notes: - a true branch child rule node is represented in the TreeView
    '          by adding a new NodeCollection to parentTreeNode.Nodes 
    '          and then adding a new TreeNode to it.
    '        - a false branch child rule node is represented in the TreeView
    '          by adding a new TreeNode to parentTreeNode.Nodes. 
    '        - task.nodelist is an arraylist of all the rdrNodes in this tree

    Private Sub AddChildTree(ByVal parentTreeNode As TreeNode, ByVal task As sTask, _
                             ByVal parentNodeID As Integer, _
                             ByVal addAsTrueBranch As Boolean)

        ' the treenode to add that will contain the true child branch rdr node
        Dim newTreeNode As TreeNode
        Dim idxChildRule, iconIndex As Integer

        ' from the parent rdr node get the node id of the branch's child
        If addAsTrueBranch Then
            idxChildRule = Convert.ToInt32(task.nodelist(parentNodeID).trueChild)
            iconIndex = 1
        Else
            idxChildRule = Convert.ToInt32(task.nodelist(parentNodeID).falseChild)
            iconIndex = 0
        End If

        ' a node id of -1 means no child on that branch
        If idxChildRule > -1 Then

            ' add a new TreeNode for the rdr node as a child of the parentTreeNode
            newTreeNode = parentTreeNode.Nodes.Add("Rule " + idxChildRule.ToString)
            newTreeNode.ImageIndex = iconIndex
            newTreeNode.SelectedImageIndex = iconIndex   ' don't change icon when sel.

            ' recurse for children of the new child node
            If NodeHasTrueChild(task, idxChildRule) Then
                AddChildTree(newTreeNode, task, idxChildRule, True)
            End If
            If NodeHasFalseChild(task, idxChildRule) Then
                AddChildTree(parentTreeNode, task, idxChildRule, False)
            End If
        End If
    End Sub

    Private Function NodeHasTrueChild(ByVal task As sTask, _
                                      ByVal nodeId As Integer) As Integer

        'return true if the node id has a true child node
        Return (Convert.ToInt32(task.nodelist(nodeId).trueChild) > -1)
    End Function

    Private Function NodeHasFalseChild(ByVal task As sTask, _
                                      ByVal nodeId As Integer) As Integer

        'return true if the node id has a false child node
        Return (Convert.ToInt32(task.nodelist(nodeId).falseChild) > -1)
    End Function

     ' fires when node is selected to update gui text fields
    Private Sub tvRules_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvRules.AfterSelect
        Dim selText As String = tvRules.SelectedNode.Text
        Dim selected As Integer = Convert.ToInt32(selText.Substring(5)) ' which node?
        Dim task As sTask = tasks(cbxTasks.SelectedIndex)               ' current task 
        Dim node As sNode = task.nodelist(selected)                     ' current node    
        Dim datalist As ArrayList = task.cslist(selected)               ' current cs
        Dim dataitem As String

        ' update textboxes
        txtID.Text = node.id
        txtParent.Text = node.parent
        txtCondition.Text = node.condition
        txtConclusion.Text = node.conclusion
        txtDesc.Text = node.desc

        ' and the cs list
        lbxCornerstone.Items.Clear()
        For Each dataitem In datalist
            lbxCornerstone.Items.Add(dataitem)
        Next
    End Sub

    ' clear controls of data
    Private Sub Clear()
        tvRules.Nodes.Clear()
        lbxCornerstone.Items.Clear()
        txtID.Text = ""
        txtParent.Text = ""
        txtCondition.Text = ""
        txtConclusion.Text = ""
        txtDesc.Text = ""
    End Sub

    ' a different task has been selected by the user
    Private Sub cbxTasks_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbxTasks.SelectedIndexChanged
        If Not loadingRules Then                             ' prevents double loading
            Clear()
            LoadTree(tasks(cbxTasks.SelectedIndex))          ' load tree for this task
        End If
    End Sub

    ' allows add form to get the cornerstone data for a rule
    Public Function getCornerstone(ByVal idx As Integer) As ArrayList
        Return tasks(cbxTasks.SelectedIndex).cslist(idx)
    End Function

    ' asks if user wants to replace running worklet after a rule addition
    Private Sub ReplaceWorklet(ByVal workitem As frmAddRule.sWorkItem)

        Dim question As String
        question = "Do you wish to immediately replace the running worklet case " & _
                   "for workitem '" & workitem.id & "' using the new rule?" & vbCrLf & _
                   vbCrLf & "Workitem Spec ID: " & workitem.specid & _
                   vbCrLf & "Workitem Task ID: " & workitem.taskid & _
                   vbCrLf & "Workitem Case ID: " & workitem.caseid & _
                   vbCrLf & "Running Worklet:  " & workitem.worklet & _
                   vbCrLf & "Worklet Case ID:  " & workitem.runningCaseId

        If MessageBox.Show(question, "Replace running worklet?", MessageBoxButtons.YesNo, _
                           MessageBoxIcon.Question) = DialogResult.Yes Then
            TriggerReplaceWorklet(workitem.id)         ' if 'yes', replace it
        End If
    End Sub

    ' tells worklet service to replace a worklet & waits for a response
    Private Function TriggerReplaceWorklet(ByVal id As String) As Stream
        Dim req As HttpWebRequest
        Dim resp As HttpWebResponse
        Dim url As String = pathOf.ServiceURL & "/gateway"     ' to wsGateway servlet
        Dim query As String = "?"
        Dim result As Stream                                   ' the response
        Dim strResp As String                                  ' converted to string

        ' build the query here 
        query &= id

        Cursor = Cursors.WaitCursor

        Try
            ' build a request from the url and the query string (i.e. the itemid)
            req = DirectCast(WebRequest.Create(url & query), HttpWebRequest)
            req.KeepAlive = False                                   ' ok to be async

            ' get the response from the service
            resp = DirectCast(req.GetResponse(), HttpWebResponse)
            result = resp.GetResponseStream
            If Not result Is Nothing Then
                strResp = StreamToString(result)                    ' convert to string
            Else
                strResp = "The worklet service failed to respond to the request."
            End If
            MessageBox.Show(strResp, "Result of replace request", MessageBoxButtons.OK, _
                           MessageBoxIcon.Information)
            resp.Close()
        Catch we As WebException
            Debug.WriteLine(we.StackTrace())
        Finally
            Cursor = Cursors.Default
        End Try
        Return result   ' not used
    End Function

    ' converts a stream (response from wsGateway) to a String
    Private Function StreamToString(ByVal s As Stream) As String
        Dim encode As Encoding = System.Text.Encoding.GetEncoding("utf-8")
        Dim sr As New StreamReader(s, encode)
        Dim ch(256) As Char                          ' Reads 256 characters at a time
        Dim result As String = ""

        Dim count As Integer = sr.Read(ch, 0, 256)   ' fill the buffer
        While count > 0
            result &= New String(ch, 0, count)       ' add to result string 
            count = sr.Read(ch, 0, 256)
        End While

        sr.Close()
        Return result
    End Function

    Private Sub mNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mNew.Click
        ' allows the creation of a new rule set
        ' Note: RDR integrity requires that only the root and one rule node can
        '       be created this way - the rest are to be added via the service

        Dim fNewRule As New frmNewRule
        Dim tryAgain As Boolean
        Dim oldSpec As String


        fNewRule.pathOf = pathOf
        If fNewRule.ShowDialog() = DialogResult.OK Then
            spec = fNewRule.specName.Replace(" "c, "_"c)       'set spaces to underscores

            fName = pathOf.repository & "\rules\" & spec & ".xrs"  ' make filename

            While File.Exists(fName)
                spec = InputBox("A rules file with the specification name supplied" & _
                                " already exists." & Chr(13) & "Please modify" & _
                                " the specification name and click OK, or click" & _
                                " Cancel to cancel the addition of a new rule set.", _
                                "Rules file exists with this name", spec)
                If spec.Length = 0 Then
                    Clear()
                    Exit Sub
                End If
                fName = pathOf.repository & "\rules\" & spec & ".xrs"  ' make filename
            End While

            ReDim tasks(0)                             ' reset tasks array
            tasks(0) = fNewRule.task

            mNew.Enabled = False                       'update gui settings
            mOpen.Enabled = False
            mClose.Enabled = True
            mAdd.Enabled = True
            loadingRules = True

            ' put task name in combo
            cbxTasks.Items.Add(tasks(0).name)          ' list task name
            cbxTasks.SelectedIndex = 0                 ' set combo to 1st task
            cbxTasks.Text = cbxTasks.Items(0)

            LoadTree(tasks(0))                         ' draw new tree in editor 

            SaveRules()                          'save the new rule set to a file

            ExtractSpecName(fName)                        ' show filename in title
        End If

    End Sub

    Private Sub mOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mOpen.Click
        ' loads a rdr ruleset into the editor 
        loadingRules = True
        If LoadRules() Then                                     ' read rules from file
            LoadTree(tasks(0))                                  ' draw tree in editor
            mClose.Enabled = True                               ' enable menus   
            mAdd.Enabled = True
            mOpen.Enabled = False
            mNew.Enabled = False
            loadingRules = False
        End If
    End Sub

    Private Sub mClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mClose.Click
        ' refresh controls & variables when a file is closed
        Clear()
        tasks = Nothing
        cbxTasks.Items.Clear()
        lbxCornerstone.Items.Clear()
        cbxTasks.Text = ""
        Me.Text = "Worklet Rules Editor"
        mAdd.Enabled = False
        mClose.Enabled = False
        mOpen.Enabled = True
        mNew.Enabled = True
        spec = ""
        fName = ""
    End Sub

    Private Sub mExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mExit.Click
        Close()
    End Sub

    Private Sub mAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mAdd.Click
        ' use a second form to gather new rule data then add it to the set of rules 
        ' for this task
        Dim fAdd As New frmAddRule
        Dim newNode, parentNode As sNode
        Dim newCS As ArrayList
        Dim isTrueBranch As Boolean                   ' is new rule added as truechild?
        Dim idxParent, idxNode As Integer
        Dim ruleAdded As Boolean
        Dim workitem As frmAddRule.sWorkItem

        With fAdd                                             ' initialise add form
            .Owner = Me
            .pathOf = pathOf
            .loadedSpec = spec
            .loadedTask = cbxTasks.Text
            .nextNodeId = tasks(cbxTasks.SelectedIndex).nodelist.Count
            If .ShowDialog() = DialogResult.OK Then           ' show it
                newNode = .newNode                            ' get data from form 
                workitem = .workItem
                isTrueBranch = .isTrueBranch
                newCS = .newCS
                ruleAdded = True                              ' OK btn pressed
            End If
        End With

        If ruleAdded Then
            idxNode = Convert.ToInt32(newNode.id)             ' index of new node  
            If idxNode > -1 Then

                ' add the node
                tasks(cbxTasks.SelectedIndex).nodelist.Insert(idxNode, newNode)
                tasks(cbxTasks.SelectedIndex).cslist.Insert(idxNode, newCS)

                ' update the parent node to reflect its new child
                idxParent = Convert.ToInt32(newNode.parent)
                parentNode = tasks(cbxTasks.SelectedIndex).nodelist(idxParent) 'get node
                If isTrueBranch Then                                       ' update node
                    parentNode.trueChild = newNode.id
                Else
                    parentNode.falseChild = newNode.id
                End If
                tasks(cbxTasks.SelectedIndex).nodelist.RemoveAt(idxParent) 'replace node
                tasks(cbxTasks.SelectedIndex).nodelist.Insert(idxParent, parentNode)

                tvRules.Nodes.Clear()                                      ' reload tree
                LoadTree(tasks(cbxTasks.SelectedIndex))
                SaveRules()
                ReplaceWorklet(workitem)                   ' ask user if replace wanted
            End If
        End If
    End Sub

    Private Sub mConfigure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mConfigure.Click
        'get paths to various resources
        Dim fConfig As New frmConfig

        If fConfig.ShowDialog = DialogResult.OK Then
            pathOf.repository = fConfig.txtRepository.Text
            pathOf.YAWLEditor = fConfig.txtYAWLEditor.Text
            pathOf.ServiceURL = fConfig.txtServiceURI.Text
        End If
    End Sub

    Private Sub frmEdit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'if user-defined paths exist, load them, otherwise assume its a first time
        Dim fConfig As New frmConfig
        Dim pathsLoaded As Boolean = False

        If File.Exists(Application.StartupPath & "\RulesEditor.cfg") Then
            fConfig.LoadPathsFromFile()
            pathsLoaded = True
        Else
            ' first time use
            MessageBox.Show("Welcome to the Worklet Rules Editor. Please enter the " & _
                            "file paths to the resources listed in the next dialog.", _
                            "Rules Editor First Time Configure", MessageBoxButtons.OK, _
                            MessageBoxIcon.Information)
            If fConfig.ShowDialog = DialogResult.OK Then
                pathsLoaded = True
            End If
        End If

        If pathsLoaded Then
            pathOf.repository = fConfig.txtRepository.Text
            pathOf.YAWLEditor = fConfig.txtYAWLEditor.Text
            pathOf.ServiceURL = fConfig.txtServiceURI.Text
        Else
            fConfig.LoadDefaultPaths()
            fConfig.SavePathsToFile()
        End If
    End Sub

    Private Sub mAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mAbout.Click
        Dim fAbout As New frmAbout
        fAbout.ShowDialog()
    End Sub
End Class
